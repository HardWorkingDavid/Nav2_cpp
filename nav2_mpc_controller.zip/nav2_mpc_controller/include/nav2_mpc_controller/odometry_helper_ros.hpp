/////////////////////////////////////////////////////////////////////////////////////////
//用于获得odom消息，并按照调用者要求返回其中主要信息的类
//常用于获得当前车速，以在规划速度时，规划出一个满足加速度约束的结果
/////////////////////////////////////////////////////////////////////////////////////////
#ifndef ODOMETRY_HELPER_ROS2_HPP_
#define ODOMETRY_HELPER_ROS2_HPP_

#include <nav_msgs/msg/odometry.hpp>
#include <rclcpp/rclcpp.hpp>

#include <mutex>
#include <string>
#include <geometry_msgs/msg/pose_stamped.hpp>

namespace nav2_mpc_controller {

class OdometryHelperRos : public rclcpp::Node {
public:
    OdometryHelperRos(std::string odom_topic = "/odom")
    : Node("odometry_helper_ros2"), odom_topic_(odom_topic) {
        // Initialize subscriber
        odom_sub_ = this->create_subscription<nav_msgs::msg::Odometry>(
            odom_topic_, 10, std::bind(&OdometryHelperRos::odomCallback, this, std::placeholders::_1));
    }
    ~OdometryHelperRos() {}

    void odomCallback(const nav_msgs::msg::Odometry::SharedPtr msg);

    void getOdom(nav_msgs::msg::Odometry& base_odom);

    void getRobotVel(geometry_msgs::msg::PoseStamped& robot_vel);

    void setOdomTopic(std::string odom_topic);

    std::string getOdomTopic() const { return odom_topic_; }

private:
    std::string odom_topic_;
    rclcpp::Subscription<nav_msgs::msg::Odometry>::SharedPtr odom_sub_;
    nav_msgs::msg::Odometry base_odom_;
    std::mutex odom_mutex_;
    std::string frame_id_;
};

} 
#define CHUNKY 1
#endif