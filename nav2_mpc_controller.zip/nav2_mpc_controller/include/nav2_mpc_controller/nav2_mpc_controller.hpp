/**
 * @file nav2_mpc_controller.hpp
 * @brief mpc
 * @author YangDawei
 * @date 2024.7.25
 * @version 0.1
*/

#pragma once

#include <string>
#include <vector>
#include <memory>
#include <eigen3/Eigen>

#include "nav2_core/controller.hpp"
#include "rclcpp/rclcpp.hpp"
#include "pluginlib/class_loader.hpp"
#include "pluginlib/class_list_macros.hpp"

#include "nav2_util/geometry_utils.hpp"
#include "geometry_msgs/msg/pose2_d.hpp"

namespace nav2_mpc_controller
{

class MPCController : public nav2_core::Controller, public rclcpp::Node
{
public:
    MPCController() : Node("mpc_node") {
        target_pt_pub_    = this->create_publisher<geometry_msgs::msg::PointStamped>("/target_point", 10);
        current_pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/current_pose", 10);
    }
    ~MPCController() override = default;

    void configure(
        const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
        std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros);


    void cleanup();
    void activate();
    void deactivate();
    void setSpeedLimit(const double & speed_limit, const bool & percentage);

    geometry_msgs::msg::TwistStamped computeVelocityCommands(
        const geometry_msgs::msg::PoseStamped & pose,
        const geometry_msgs::msg::Twist & velocity,
        nav2_core::GoalChecker * goal_checker);

    void setPlan(const nav_msgs::msg::Path & path);

protected:
    bool isGoalReached();

    void transformPose(std::shared_ptr<tf2_ros::Buffer> tf, const std::string out_frame, const geometry_msgs::msg::PoseStamped& in_pose,
                        geometry_msgs::msg::PoseStamped& out_pose) const;

    Eigen::Vector2d MpcControl(Eigen::Vector3d s, Eigen::Vector3d s_d, Eigen::Vector2d u_r, Eigen::Vector2d du_p);
  
private:
    // flag
    bool initialized_ = false;
    bool goal_reached_ = false;

    OdometryHelperRos* odom_helper_;

    rclcpp_lifecycle::LifecycleNode::WeakPtr node_;
    
    std::shared_ptr<tf2_ros::Buffer> tf_;
    std::string plugin_name_;
    std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros_;
    rclcpp::Logger logger_ {rclcpp::get_logger("MPCController")};
    rclcpp::Clock::SharedPtr clock_;

    double dt_;
    Eigen::Matrix3d Q_;
    Eigen::Matrix2d R_;
    int predict_time_;
    double control_time_;
    Eigen::Vector2d previous_control_error_;

    double goal_x_, goal_y_;
    Eigen::Vector3d goal_rpy_;

    nav_msgs::msg::Path global_plan_;

    std::shared_ptr<rclcpp_lifecycle::LifecyclePublisher<geometry_msgs::msg::PointStamped>> target_pt_pub_;
    std::shared_ptr<rclcpp_lifecycle::LifecyclePublisher<geometry_msgs::msg::PoseStamped>> current_pose_pub_;
};

}  // namespace nav2_mpc_controller