#include "nav2_mpc_controller/nav2_mpc_controller.hpp"
#include <vector>
#include <casadi/casadi.hpp>
#include <nav_2d_msgs/msg/odometry.hpp>

using namespace std;
using namespace casadi;
using std::hypot;
using std::min;
using std::max;
using std::abs;
using nav2_util::declare_parameter_if_not_declared;
using nav2_util::geometry_utils::euclidean_distance;
using namespace nav2_costmap_2d;  // NOLINT
using rcl_interfaces::msg::ParameterType;

namespace nav2_mpc_controller {

void MPCController::configure(
            const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
            std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
            const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) {
    if (!initialized_) {
        node_ = parent;
        auto node = node_.lock();

        costmap_ros_ = costmap_ros;
        tf_ = tf;
        plugin_name_ = name;
        logger_ = node->get_logger();
        clock_ = node->get_clock();
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".goal_dist_tolerance", rclcpp::ParameterValue(
            0.2));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".rotate_tolerance",
            rclcpp::ParameterValue(0.4));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".lookahead_time", rclcpp::ParameterValue(
            1.5));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".min_lookahead_dist", rclcpp::ParameterValue(
            0.3));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".max_lookahead_dist", rclcpp::ParameterValue(
            0.6));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".max_v", rclcpp::ParameterValue(
            0.25));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".min_v", rclcpp::ParameterValue(
            0.0));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".max_v_inc", rclcpp::ParameterValue(
            0.5));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".max_w", rclcpp::ParameterValue(
            1.57));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".min_w", rclcpp::ParameterValue(
            0.0));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".max_w_inc", rclcpp::ParameterValue(
            1.57));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".predict_time", rclcpp::ParameterValue(
            4));
        declare_parameter_if_not_declared(
            node, plugin_name_ + ".control_time", rclcpp::ParameterValue(
            4));

        node->get_parameter(plugin_name_ + ".goal_dist_tolerance", goal_dist_tolerance_);
        node->get_parameter(plugin_name_ + ".rotate_tolerance", rotate_tolerance_);
        node->get_parameter(plugin_name_ + ".lookahead_time", lookahead_time_);
        node->get_parameter(plugin_name_ + ".min_lookahead_dist", min_lookahead_dist_);
        node->get_parameter(plugin_name_ + ".max_lookahead_dist", max_lookahead_dist_);
        node->get_parameter(plugin_name_ + ".max_v", max_v_);
        node->get_parameter(plugin_name_ + ".min_v", min_v_);
        node->get_parameter(plugin_name_ + ".max_v_inc", max_v_inc_);
        node->get_parameter(plugin_name_ + ".max_w", max_w_);
        node->get_parameter(plugin_name_ + ".min_w", min_w_);
        node->get_parameter(plugin_name_ + ".max_w_inc", max_w_inc_);
        node->get_parameter(plugin_name_ + ".predict_time", predict_time_);
        node->get_parameter(plugin_name_ + ".control_time", control_time_);

        // weight matrix for penalizing state error while tracking [x,y,theta]
        std::vector<double> diag_vec;
        Q_ = Eigen::Matrix3d::Zero();

        for (size_t i = 0; i < diag_vec.size(); ++i)
            Q_(i, i) = diag_vec[i];
        
        // weight matrix for penalizing input error while tracking[v, w]
        R_ = Eigen::Matrix2d::Zero();
        for (size_t i = 0; i < diag_vec.size(); ++i)
            R_(i, i) = diag_vec[i];
        double controller_freqency = 10.0;
        dt_ = 1 / controller_freqency;

        RCLCPP_INFO("MPC controller initialized!");
    } else {
        RCLCPP_INFO("MPC controller has already been initialized.");
    }
}

void MPCController::cleanup()
{
    RCLCPP_INFO(
        logger_,
        "Cleaning up controller: %s of type nav2_mpc_controller::MPCController",
        plugin_name_.c_str());
        
    target_pt_pub_.reset();
    current_pose_pub_.reset();
}

void MPCController::activate()
{
    RCLCPP_INFO(
        logger_,
        "Activating controller: %s of type nav2_mpc_controller::MPCController\"  %s",
        plugin_name_.c_str(),plugin_name_.c_str());
    target_pt_pub_->on_activate();
    current_pose_pub_->on_activate();
}

void MPCController::deactivate()
{
    RCLCPP_INFO(
        logger_,
        "Dectivating controller: %s of type nav2_mpc_controller::MPCController\"  %s",
        plugin_name_.c_str(),plugin_name_.c_str());
    target_pt_pub_->on_deactivate();
    current_pose_pub_->on_deactivate();
}

void MPCController::setSpeedLimit(const double & speed_limit, const bool & percentage) 
{
    (void) speed_limit;
    (void) percentage;
}

void MPCController::setPlan(const nav_msgs::msg::Path & path)
{
    if (!initialized_) {
        RCLCPP_ERROR("This controller has not been initialized, please call initialize() before using this controller");
        return false;
    }
    RCLCPP_INFO("Got new plan");
    // set new plan
    global_plan_.clear();
    global_plan_ = path;

    // reset plan parameters
    if (goal_x_ != global_plan_.back().pose.position.x || goal_y_ != global_plan_.back().pose.position.y)
    {
        goal_x_ = global_plan_.back().pose.position.x;
        goal_y_ = global_plan_.back().pose.position.y;
        goal_rpy_ = getEulerAngles(global_plan_.back());
        goal_reached_ = false;
    }
    return true;
}

/**
 * @brief Check if the goal pose has been achieved
 * @return true if achieved, false otherwise
 */
bool MPCController::isGoalReached()
{
  if (!initialized_)
  {
    RCLCPP_ERROR("MPC controller has not been initialized");
    return false;
  }

  if (goal_reached_)
  {
    RCLCPP_INFO("GOAL Reached!");
    return true;
  }
  return false;
}

geometry_msgs::msg::TwistStamped MPCController::computeVelocityCommands(
        const geometry_msgs::msg::PoseStamped & pose,
        const geometry_msgs::msg::Twist & velocity,
        nav2_core::GoalChecker * goal_checker) {
    (void)velocity;
    (void)goal_checker;
    // odometry observation - getting robot velocities in robot frame
    nav_msgs::msg::Odometry base_odom;
    odom_helper_->getOdom(base_odom);

    // get robot position in global frame
    geometry_msgs::msg::PoseStamped robot_pose_odom, robot_pose_map;
    costmap_ros_->getRobotPose(robot_pose_odom);
    transformPose(tf_, map_frame_, robot_pose_odom, robot_pose_map);

    
    auto goal_pose = goal_pose_it->pose;

    double linear_vel, angular_vel;

    
    if (goal_pose.position.x > 0) {
        auto curvature = 2.0 * goal_pose.position.y /
        (goal_pose.position.x * goal_pose.position.x + goal_pose.position.y * goal_pose.position.y);
        linear_vel = desired_linear_vel_;
        angular_vel = desired_linear_vel_ * curvature;
    } else {
        linear_vel = 0.0;
        angular_vel = max_angular_vel_;
    }

    // Create and publish a TwistStamped message with the desired velocity
    geometry_msgs::msg::TwistStamped cmd_vel;
    cmd_vel.header.frame_id = pose.header.frame_id;
    cmd_vel.header.stamp = clock_->now();
    cmd_vel.twist.linear.x = linear_vel;
    cmd_vel.twist.angular.z = max(
        -1.0 * abs(max_angular_vel_), min(
        angular_vel, abs(
            max_angular_vel_)));

    return cmd_vel;
}

void MPCController::transformPose(std::shared_ptr<tf2_ros::Buffer> tf, const std::string out_frame, const geometry_msgs::msg::PoseStamped& in_pose,
                        geometry_msgs::msg::PoseStamped& out_pose) const 
{
    if (in_pose.header.frame_id == out_frame)
        out_pose = in_pose;

    tf->transform(in_pose, out_pose, out_frame);
    out_pose.header.frame_id = out_frame;
}

};


// Register this controller as a nav2_core plugin
PLUGINLIB_EXPORT_CLASS(
  nav2_mpc_controller::MPCController,
  nav2_core::Controller)
