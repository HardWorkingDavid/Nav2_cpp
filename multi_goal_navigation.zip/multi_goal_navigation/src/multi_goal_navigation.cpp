#include "rclcpp/rclcpp.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "nav2_msgs/action/navigate_to_pose.hpp"
#include "yaml-cpp/yaml.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"

int main() {
    
}
/*typedef rclcpp::Node Node;
typedef rclcpp::Publisher<geometry_msgs::msg::PoseStamped>::SharedPtr PoseStampedPublisher;
typedef rclcpp::Client<nav2_msgs::action::NavigateToPose>::SharedPtr NavigateToPoseClient;

int main(int argc, char argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<Node>("multi_goal_navigation");  
    auto nav_client = node->create_client<nav2_msgs::action::NavigateToPose>("navigate_to_pose");

    while (!nav_client->wait_for_service(std::chrono::seconds(5))) {
        RCLCPP_INFO(node->get_logger(), "Waiting for the navigate_to_pose action server to come up");
    }

    YAML::Node config = YAML::LoadFile("../config/muti_goal.yaml");
    const auto& goals = config["goal_pose"];

    for (const auto& goal : goals) {
        auto goal_msg = nav2_msgs::action::NavigateToPose::Goal();
        goal_msg.pose.header.frame_id = "map";
        goal_msg.pose.header.stamp = node->now();
        goal_msg.pose.pose.position.x = goal["x"].as<double>();
        goal_msg.pose.pose.position.y = goal["y"].as<double>();
        goal_msg.pose.pose.orientation = tf2::toMsg(tf2::Quaternion(tf2::Vector3(0, 0, 1), goal["yaw"].as<double>()));

        RCLCPP_INFO_STREAM(node->get_logger(), "Sending goal: " << goal_msg.pose);

        /*auto result_future = nav_client->async_send_goal(goal_msg);

        if (rclcpp::spin_until_future_complete(node, result_future) == rclcpp::FutureReturnCode::SUCCESS) {
            auto result = result_future.get();
        if (result.code == rclcpp_action::ResultCode::SUCCEEDED) {
            RCLCPP_INFO(node->get_logger(), "Goal reached successfully");
        } else {
            RCLCPP_ERROR(node->get_logger(), "Failed to reach goal");
        }
        } else {
            RCLCPP_ERROR(node->get_logger(), "Failed to get result");
        }
    }

    rclcpp::shutdown();
    return 0;
}*/