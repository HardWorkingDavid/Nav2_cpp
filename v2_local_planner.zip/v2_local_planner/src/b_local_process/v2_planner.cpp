#include <cmath>
#include <angles/angles.h>

#include "rclcpp/rclcpp.hpp"
#include <tf2/utils.h>
#include <sensor_msgs/msg/point_cloud2.hpp>
#include <sensor_msgs/point_cloud2_iterator.hpp>
#include <nav2_costmap_2d/cost_values.hpp>

#include "b_local_process/v2_planner.hpp"

namespace v2_local_planner{

V2Planner::V2Planner(std::string name, 
                     PathManagerCore *pathManagerCore,
                     fileWrite* fileWrite,
                     tf2_ros::Buffer* tf,
                     costmap_2d::Costmap2D* costmap_local,
                     std::string global_frame_local,
                     costmap_2d::Costmap2D* costmap_global,
                     std::string global_frame_global ) :
    pathManagerCore_(pathManagerCore),
    fileWrite_(fileWrite),
    obstacle_costs_(pathManagerCore_->getLocalCostmap()),
    tf_(tf),
    costmap_local_(costmap_local),
    costmap_frame_local_(global_frame_local),
    costmap_global_(costmap_global),
    costmap_frame_global_(global_frame_global){

  ros::NodeHandle private_nh("~/" + name);
  //设定控制周期-------------------------------------------------------------------------------
  std::string controller_frequency_param_name;
  if(!private_nh.searchParam("controller_frequency", controller_frequency_param_name)) {
    sim_period_ = 0.05;
  } else {
    double controller_frequency = 0;
    private_nh.param(controller_frequency_param_name, controller_frequency, 20.0);
    if(controller_frequency > 0) {
      sim_period_ = 1.0 / controller_frequency;
    } else {
      ROS_WARN("A controller_frequency less than 0 has been set. Ignoring the parameter, assuming a rate of 20Hz");
      fileWrite_->writeWarn("A controller_frequency less than 0 has been set. Ignoring the parameter, assuming a rate of 20Hz");
        
      sim_period_ = 0.05;
    }
  }
  ROS_INFO("Sim period is set to %.2f", sim_period_);
  fileWrite_->write("Sim period is set to ");
  fileWrite_->writeEnd(std::to_string(sim_period_));

  //障碍物评价器的评价方式：是做所有点的评分总和，还是发现障碍物立即返回false-----------------------
  bool sum_scores;
  private_nh.param("sum_scores", sum_scores, false);
  obstacle_costs_.setSumScores(sum_scores);

}


/*************************************************************************************************
 * @brief: 给定机器人在local costmap中的pose(pos)、当前速度(vel)和设定的速度(vel_samples)，
 *         检查是否会发生碰撞
 *************************************************************************************************/
bool 
V2Planner::checkTrajectory(
    Eigen::Vector3f pos,
    Eigen::Vector3f vel,
    Eigen::Vector3f vel_samples){

  v2_local_planner::Trajectory traj;

  v2_local_planner::LocalPlannerLimits limits = pathManagerCore_->getCurrentLimits();

  generator_.generateTrajectoryOutside(pos, vel, vel_samples, traj, &limits);

  double distance;

  double cost = obstacle_costs_.scoreTrajectory(traj);
  //return true;

  if(cost >= 0) {
    return true;
  }
  ROS_WARN("Invalid Trajectory %f, %f, %f, cost: %f", 
           vel_samples[0], vel_samples[1], vel_samples[2], cost);
  return false;

}

/*************************************************************************************************
 * @brief: 给定机器人在local costmap中的pose(pos)、当前速度(vel)和设定的速度(vel_samples)，
 *         检查是否会发生碰撞，并返回预测到的碰撞距离以及碰撞位置
 *************************************************************************************************/
bool 
V2Planner::checkTrajectoryWithInvalidDistance(
    Eigen::Vector3f pos,
    Eigen::Vector3f vel,
    Eigen::Vector3f vel_samples,
    bool show_or_not,
    double& invalid_distance,
    std::vector<bool>& colli_parts){
  std::cout<<"(v2_planner.cpp): checkTrajectoryWithInvalidDistance()"<<std::endl;
  fileWrite_->writeEnd("(v2_planner.cpp): checkTrajectoryWithInvalidDistance()","brown");

  bool front, back, left, right;
  v2_local_planner::Trajectory traj;

  v2_local_planner::LocalPlannerLimits limits = pathManagerCore_->getCurrentLimits();
    
  if(!generator_.generateTrajectoryOutside(pos, vel, vel_samples, traj, &limits)){
    return false;
  }
    
  double cost = obstacle_costs_.scoreTrajectoryWithInvalidDistance(traj, invalid_distance,
                                                                     front, back, left, right,
                                                                     show_or_not);
 
  if(cost >= 0) { return true; }
  colli_parts.push_back(front);
  colli_parts.push_back(back);
  colli_parts.push_back(left);
  colli_parts.push_back(right);

  return false;

}


/*************************************************************************************************

 *************************************************************************************************/
bool
V2Planner::updatePlanAndLocalCosts(
    const geometry_msgs::PoseStamped& current_pose_global,
    const geometry_msgs::PoseStamped& current_pose_local,
    const std::vector<geometry_msgs::PoseStamped>& path_seg_map,
    const std::vector<geometry_msgs::Point>& footprint_spec){

  std::cout<<"(v2_planner.cpp): updatePlanAndLocalCosts()"<<std::endl;
  fileWrite_->writeEnd("(v2_planner.cpp): updatePlanAndLocalCosts()","brown");

  //===============================================
  //                                       更新位姿
  //===============================================
  current_pose_global_ = current_pose_global;
  current_pose_local_ = current_pose_local;

  //===============================================
  //               更新本地路径并进行全局到局部的变换
  //===============================================
  PoseStampedVec       global_plan_seg_ori;
  global_plan_seg_pruned_.clear();
  local_plan_seg_pruned_.clear();

  std::cout<<"path_seg_map size:"<<std::to_string(path_seg_map.size())<<std::endl;
  fileWrite_->write("path_seg_map size:");
  fileWrite_->writeEnd(std::to_string(path_seg_map.size()));

  for(int i = 0; i < path_seg_map.size(); i++){
    global_plan_seg_ori.push_back(path_seg_map[i]);
  }

  std::cout<<"global_plan_seg_ori size:"<<std::to_string(global_plan_seg_ori.size())<<std::endl;
  fileWrite_->write("global_plan_seg_ori size:");
  fileWrite_->writeEnd(std::to_string(global_plan_seg_ori.size()));


  if(!v2_local_planner::transformGlobalPlanWithSoftPrune(
        *tf_,
        global_plan_seg_ori,
        current_pose_local_,
        *costmap_local_,
        costmap_frame_local_,
        global_plan_seg_pruned_,
        local_plan_seg_pruned_,
        0)){

    std::cout<<"\033[31mcannot transform global plan to local costmap frame\033[0m"<<std::endl;
    fileWrite_->writeError("cannot transform global plan to local costmap frame");
    return false;
  }


  std::cout<<"local_plan_seg_pruned_ size:"<<std::to_string(local_plan_seg_pruned_.size())<<std::endl;
  fileWrite_->write("local_plan_seg_pruned_ size:");
  fileWrite_->writeEnd(std::to_string(local_plan_seg_pruned_.size()));

  std::cout<<"global_plan_seg_pruned_ size:"<<std::to_string(global_plan_seg_pruned_.size())<<std::endl;
  fileWrite_->write("global_plan_seg_pruned_ size:");
  fileWrite_->writeEnd(std::to_string(global_plan_seg_pruned_.size()));

  //===============================================
  //                                配置一些功能部件
  //===============================================    
  //std::cout<<"\033[45mfootprint_spec.size:"<<std::to_string(footprint_spec.size())<<"\033[0m"<<std::endl;
  obstacle_costs_.setFootprint(footprint_spec);


  if(local_plan_seg_pruned_.size() == 0){
    std::cout<<"\033[31mlocal_plan_seg_pruned_ size error!\033[0m"<<std::endl;
    fileWrite_->writeError("local_plan_seg_pruned_ size error!");

    return false;
  }

  if(global_plan_seg_pruned_.size() == 0){
    std::cout<<"\033[31mglobal_plan_seg_pruned_ size error!\033[0m"<<std::endl;
    fileWrite_->writeError("global_plan_seg_pruned_ size error!");

    return false;
  }

  if(global_plan_seg_pruned_.size() != local_plan_seg_pruned_.size()){
    std::cout<<"\033[31mplan_seg_pruned_ size error! not equal\033[0m"<<std::endl;
    fileWrite_->writeError("plan_seg_pruned_ size error! not equal");

    return false;
  }
  return true;
}




/*************************************************************************************************
 * @brief:        使用updatePlanAndLocalCosts更新的全局、局部规划路段，以及当前小车的pose
 *                根据当前的路况，和小车的行驶情况，选择一个合适的跟踪点
 * @params:       circumscribed_radius:     车身的外接圆半径
                  inscribed_radius:         车身的内接圆半径
                  seg_type:                 当前执行路段的类型
                  pursuit_pose:             在局部坐标系下的pursuit pose位姿，
                                            传给velocity_controller
                  pursuit_pose_viz_global:  在全局坐标系下的pursuit pose位姿
                                            用来在planner_ros中打印萝卜
                  emergency_trigger:        是否是紧急状态，传给velocity_controller
                                            用来判断是否应该减速
 *TODO:           没有空路段检测                  
 *************************************************************************************************/
bool
V2Planner::pursuitPose(
    const double& circumscribed_radius,
    const double& inscribed_radius,
    const std::string& seg_type,
    geometry_msgs::PoseStamped& pursuit_pose,
    geometry_msgs::PoseStamped& pursuit_pose_viz_global,
    bool& emergency_trigger){

  std::cout<<"(v2_planner.cpp): pursuitPose()"<<std::endl;
  fileWrite_->writeEnd("(v2_planner.cpp): pursuitPose()","brown");

  emergency_trigger = false;

  bool casual_pursuit_pose_found = false;
  bool emergency_pursuit_pose_found = false;

  geometry_msgs::PoseStamped pursuit_pose_global_casual;
  geometry_msgs::PoseStamped pursuit_pose_global_emergency;

  geometry_msgs::PoseStamped pursuit_pose_casual;
  geometry_msgs::PoseStamped pursuit_pose_emergency;

  double current_distance;

  //========================================================
  //                                              合法性判断
  //========================================================
  if(local_plan_seg_pruned_.size() == 0 || global_plan_seg_pruned_.size() == 0 ||
     local_plan_seg_pruned_.size() != global_plan_seg_pruned_.size()){
    std::cout<<"\033[31mplan seg size error\033[0m"<<std::endl;
    fileWrite_->writeError("plan seg size error");
    return false;
  }

  //========================================================
  //                           选取正常引导pose和紧急引导pose
  //========================================================
  for(int i = 0; i < global_plan_seg_pruned_.size(); i++){
    current_distance = v2_local_planner::distanceBetweenPoses(global_plan_seg_pruned_[i],
                                                              current_pose_global_); 
    if(current_distance < 1.5 * circumscribed_radius){
      pursuit_pose_casual = local_plan_seg_pruned_[i]; 
      pursuit_pose_global_casual = global_plan_seg_pruned_[i];

      casual_pursuit_pose_found = true;

      if(0.6 * circumscribed_radius < current_distance &&
         current_distance < circumscribed_radius){
        pursuit_pose_emergency = local_plan_seg_pruned_[i];
        pursuit_pose_global_emergency = global_plan_seg_pruned_[i];

        emergency_pursuit_pose_found = true;
      }
    }else{
      break;
    }
  }

  //========================================================
  //                                                保底机制
  //========================================================
  //正常跟踪点保底
  if(!casual_pursuit_pose_found){
    std::cout<<"haven't found a causual pursuit pose"<<std::endl;

    pursuit_pose_casual = local_plan_seg_pruned_.back();
    pursuit_pose_global_casual = global_plan_seg_pruned_.back();
  }

  //紧急跟踪点保底
  if(!emergency_pursuit_pose_found){
    std::cout<<"haven't found a emergency pursuit pose"<<std::endl;

    if(local_plan_seg_pruned_.size() >= 3){
      pursuit_pose_emergency = local_plan_seg_pruned_[2];
      pursuit_pose_global_emergency = global_plan_seg_pruned_[2];
    }else if(local_plan_seg_pruned_.size() >= 2){
      pursuit_pose_emergency = local_plan_seg_pruned_[1];
      pursuit_pose_global_emergency = global_plan_seg_pruned_[1];
    }else{
      pursuit_pose_emergency = local_plan_seg_pruned_[0];
      pursuit_pose_global_emergency = global_plan_seg_pruned_[0];
    }

  }

  //========================================================
  //                           判断是否需要用紧急引导pose引导
  //========================================================
  //判断路段与障碍物的接近程度，如果较近，则使用近距离引导
  double distance_pursuit_pose_to_distance;
  double distance_current_pose_to_distance;
  std::vector<double> invalid_position_x;
  std::vector<double> invalid_position_y;
  
  pursuit_pose = pursuit_pose_casual;
  //TODO: 待优化为安全走廊模型
  //这里的判断方法尚不成熟，先行曲线
  //================跟踪点是否与障碍物过近================//
  /*
  poseCheckCircle(pursuit_pose_global_casual,
                  circumscribed_radius,
                  distance_pursuit_pose_to_distance,
                  invalid_position_x,
                  invalid_position_y);

  if(distance_pursuit_pose_to_distance < 2*circumscribed_radius){
    std::cout<<"casual pursuit pose is close to obstacle"<<std::endl;
    pursuit_pose = pursuit_pose_emergency;
    //emergency_trigger = true;
      
  }
  //===============当前位置是否与障碍物过近===============//
  poseCheckCircle(current_pose_global_,
                  circumscribed_radius,
                  distance_current_pose_to_distance,
                  invalid_position_x,
                  invalid_position_y);

  if(distance_current_pose_to_distance < 2*circumscribed_radius){
    std::cout<<"current pose is close to obstacle"<<std::endl;
    pursuit_pose = pursuit_pose_emergency;
    //emergency_trigger = true;
  }
    
  */
  //==================TODO: 曲率判断===================//


  //============当前执行路段是不是混合A*路段============//
  if(seg_type == "forward_line" || seg_type == "forward_curve" ||
     seg_type == "back_line"    || seg_type == "back_curve"){
    std::cout<<"hybrid seg"<<std::endl;
    pursuit_pose = pursuit_pose_emergency;
    emergency_trigger = true;
  }


  //========================================================
  //                           如果需要紧急引导则修改引导pose
  //========================================================
  if(!emergency_trigger){
    pursuit_pose_viz_global = pursuit_pose_global_casual;
  }else{
    pursuit_pose_viz_global = pursuit_pose_global_emergency;    
  }


  return true;
}

/*************************************************************************************************
 * @brief: 判断一个路段是否是弯曲型路段
 * @note: 主要是为了在有急转角时，能进入emergency状态，降速并缩短引导距离，以顺利过弯
 * 
 *************************************************************************************************/
bool 
V2Planner::isCurve(
    std::vector<geometry_msgs::PoseStamped>& path_seg){

  double yaw_old;
  double yaw_current;
  double eps = 1e-6;
  yaw_old = tf2::getYaw(path_seg[0].pose.orientation);
  for(int i = 1; i < path_seg.size(); i++){
    yaw_current = tf2::getYaw(path_seg[i].pose.orientation);
    if(abs(yaw_current - yaw_old) < eps){
      yaw_old = yaw_current;
    }else{
      return true;
    }
  }
  return false;
}

void 
V2Planner::poseCheckCircle(
    const geometry_msgs::PoseStamped& check_pose,
    const double& circumscribed_radius,
    double& invalid_radius,
    std::vector<double>& invalid_position_x,
    std::vector<double>& invalid_position_y){

  obstacle_costs_.poseCircleCheck(check_pose,
                                  circumscribed_radius,
                                  invalid_radius,
                                  invalid_position_x,
                                  invalid_position_y);
}


}
