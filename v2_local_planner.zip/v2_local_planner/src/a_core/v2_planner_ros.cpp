#include "a_core/v2_planner_ros.hpp"
#include <Eigen/Core>

#include <cmath>
#include <iostream>
#include <nav_msgs/msg/path.hpp>

using namespace std;

namespace v2_local_planner {

V2PlannerROS::V2PlannerROS() : initialized_(false), 
                               odom_helper_("odom"), 
                               velocityController_("velocity_controller_layer"),
                               setup_(false), 
                               robot_charging_flag_(false), 
                               robot_stationing_flag_(false), 
                               robot_charging_flag_v2_(false), 
                               robot_stationing_flag_v2_(false),
                               robot_charged_flag_v2_(false),
                               robot_stationed_flag_v2_(false),
                               is_the_final_(false) {}

void configure(
        const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
        std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros) {
    if (!isInitialized()) {
        std::cout << "Z added:(v2_planner_ros.cpp): initializing" << std::endl;
        // 日志记录类
        fileWrite_ = new v2_local_planner::fileWrite("/home/bigdavid/Nav2/src/logger/navigation_log.txt");
        fileWrite_->writeEnd("(v2_planner_ros.cpp): initializing");

        fileWrite_->write("name:");
        fileWrite_->writeEnd(name);

        tf_ = tf;

        // 存储代价地图的指针，用于向各个需要的部件分发
        costmap_ros_local_ = costmap_ros_local;
        costmap_local_ = costmap_ros_local_->getCostmap();

        costmap_ros_global_ = costmap_ros_global;
        costmap_global_ = costmap_ros_global_->getCostmap();

        // 存储机器人描述参数：外接圆半径、内接圆半径
        PointVec footprint_spec = costmap_ros_local_ ->getRobotFootprint();
        nav2_costmap_2d::calculateMinAndMaxDistances(footprint_spec,inscribed_radius_,circum_radius_);
        std::cout << "inscribed radius:" << std::to_string(inscribed_radius_) << std::endl;
        std::cout << "circumscribed radius:" << std::to_string(circum_radius_) << std::endl;
        fileWrite_->write("inscribed radius:");
        fileWrite_->writeEnd(std::to_string(inscribed_radius_));
        fileWrite_->write("circumscribed radius:");
        fileWrite_->writeEnd(std::to_string(circum_radius_));

        // 配置全局层（全局路径管理器） 
        pathManagerCore_.initialize(
            tf,  
            costmap_local_,  costmap_ros_local_->getGlobalFrameID(),
            costmap_global_, costmap_ros_global_->getGlobalFrameID(), fileWrite_);

        pathManagerCore_.setFootprint(costmap_ros_local_ ->getRobotFootprint());

        // 配置局部层 
        v2p_ = boost::shared_ptr<V2Planner>(
               new V2Planner("local_layer", &pathManagerCore_, fileWrite_, tf_, 
                            costmap_local_, costmap_ros_local_->getGlobalFrameID(),
                            costmap_global_, costmap_ros_global_->getGlobalFrameID()));
        // 配置速度层
        velocityController_.initialize(&pathManagerCore_, fileWrite_);
        // 人工干预相关
        // 求救信号发布器

        // “清除地图”操作相关的标志位和计数器
        timer_ = 0;
        timer_1_ = 20;
        counter_too_near_ = 0;
        clear_map_flag_ = false;
        clear_map_time_ = 0;

        // 里程计处理器
        // 主要用来从里程计数据中获得当前的车速，多为速度控制器使用

        /********************
         * 
         * 
         * 里程计处理器中间的参数加载待解决
        */

        // 可视化发布
        pursuit_pose_pub_ = this->create_publisher<geometry_msgs::msg::PoseStamped>("/pursuit_pose", 1);
        pursuit_point_pub_ = this->create_publisher<geometry_msgs::msg::PointStamped>("/pursuit_point", 1);

        // 速度发布器
        vel_pub_ = this->create_publisher<geometry_msgs::msg::Twist>("/cmd_vel",1);

        // 动态重配置带解决

        poses_left_current_seg_ = 99;  
        near_to_goal_flag_ = false;
        maneuver_counter_ = 0;
        
        initialized_ = true;
    } else {
        std::cout << "This planner has already been initialized, doing nothing." << std::endl;
        fileWrite_->writeWarn("This planner has already been initialized, doing nothing.");
    }
}

void setPlan(const nav_msgs::msg::Path & path) {
    // 合法性检查
    if (!isInitialized()) {
        std::cout << "This planner has not been initialized, please call initialize() before using this planner" << std::endl;
        fileWrite_->writeError("(v2_planner_ros.cpp):setPlan This planner has not been initialized");
    }

    if (!costmap_ros_global_->getRobotPose(current_pose_global_)) {
        std::cout << "Could not get robot pose" << std::endl;
        fileWrite_->writeError("Could not get robot pose");
    }
    // 获得新的plan后，修改速度控制器的相关标志位
    velocityController_.goal_reached_flag_ = false;
    velocityController_.resetLatching();

    // debug打印，可删除
    std::cout << "(v2_planner_ros.cpp):current_pose_global_:" << std::endl;
    v2_local_planner::coutPose(current_pose_global_);
    fileWrite_->writeEnd("(v2_planner_ros.cpp):current_pose_global_:");
    fileWrite_->writePose(current_pose_global_);

    std::cout << "(v2_planner_ros.cpp)::setPlan(): Got new plan");  << std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp)::setPlan(): Got new plan");

    std::cout << "Z added:(v2_planner_ros.cpp): The global_plan is refered to frame:"
              <<orig_global_plan[0].header.frame_id << std::endl;
    fileWrite_->write("Z added:(v2_planner_ros.cpp): The global_plan is refered to frame:");
    fileWrite_->writeEnd(orig_global_plan[0].header.frame_id);
    // 全局路径存入全局路径管理器
    bool isok;
    isok = pathManagerCore_.setPlan(orig_global_plan , current_pose_global_);
    //TODO: resetflags()
    if(isok == true) {
        std::cout << "successfully set plan" << std::endl;
        if (pathManagerCore_.path_.size() == 1)
        is_the_final_ = true;
    } else {
        std::cout << "fail to set plan" << std::endl;
    }
}

// 检查是否到达最终目标
bool V2PlannerROS::isGoalReached() {
    // 合法性检查
    if (! isInitialized()) {
        std::cout << "This planner has not been initialized, please call initialize() before using this planner" << std::endl;
        fileWrite_->writeError("This planner has not been initialized, please call initialize() before using this planner");
        return false;
    }

    if (!costmap_ros_local_->getRobotPose(current_pose_local_)) {
        std::cout << "(v2_planner_ros.cpp)::isGoalReached(): Could not get robot pose" << std::endl;
        fileWrite_->writeError("(v2_planner_ros.cpp)::isGoalReached(): Could not get robot pose");
        return false;
    }

    // debug打印，可删除
    if(velocityController_.isGoalReached(odom_helper_, current_pose_local_)){
        std::cout << "velocityController_:goal_reached" << std::endl;
        fileWrite_->writeEnd("velocityController_:goal_reached");
    }

    if(velocityController_.goal_reached_flag_){
        std::cout << "velocityController_:force" << std::endl;
        fileWrite_->writeEnd("velocityController_:force");
    }

    // 判断是否到达目标
    if(velocityController_.isGoalReached(odom_helper_, current_pose_local_)||
        velocityController_.goal_reached_flag_) {
        std::cout << "Goal reached" << std::endl;
        fileWrite_->writeEnd("Goal reached");
        return true;
    } else {
        std::cout << "MOVING" << std::endl;
        fileWrite_->writeEnd("MOVING");
        return false;
    }
}

//  速度计算核心
geometry_msgs::msg::TwistStamped computeVelocityCommands(const geometry_msgs::msg::Twist & velocity) {
    std::cout<<"*******************************************"<<std::endl;
    std::cout<<"(v2_planner_ros.cpp):computing the velocity"<<std::endl;
    std::cout<<"*******************************************"<<std::endl;
    fileWrite_->writeEnd("*******************************************","purple");
    fileWrite_->writeEnd("(v2_planner_ros.cpp):computing the velocity","purple");
    fileWrite_->writeEnd("*******************************************","purple");
    // 获得当前机器人的位姿
    if (!costmap_ros_local_->getRobotPose(current_pose_local_)) {
        RCLCPP_ERROR("Could not get robot pose local");
        fileWrite_->writeError("(v2_planner_ros.cpp):Could not get robot pose local");
    }
    if (!costmap_ros_global_->getRobotPose(current_pose_global_)) {
        RCLCPP_ERROR("Could not get robot pose global");
        fileWrite_->writeError(" (v2_planner_ros.cpp):Could not get robot pose global");
    }
    // 获得当前机器人的运动限制
    //后面会作为传入参数传给速度计算方法，使其可以根据参数计算出满足限制条件的速度 
    limits_ = pathManagerCore_.getCurrentLimits();
    // local_plan非法点位距离
    // local_plan中发生碰撞的位置与当前位置之间的距离，用于非法路径避障处理 
    distance_to_invaid_pose_get_local_plan_ = -1;
    // 地图清理后的缓冲时间
    if(timer_1_ < 3) {
        timer_1_++;
    }
    // 速度预测障碍距离过近时，执行脱困策略
    if(collision_maneuver_flag_) {
        if(velocityForseeCollisionManeuver()) {
            cmd_vel.linear.x = 0.0;
            cmd_vel.linear.y = 0.0;
            cmd_vel.linear.z = 0.0;
            cmd_vel.angular.x = 0.0;
            cmd_vel.angular.y = 0.0;
            cmd_vel.angular.z = 0.0;

            collision_maneuver_flag_ = false;
            maneuver_counter_ = 0;
            counter_too_near_ = 0;
        } else {
            cmd_vel.linear.x = 0.0;
            cmd_vel.linear.y = 0.0;
            cmd_vel.linear.z = 0.0;
            cmd_vel.angular.x = 0.0;
            cmd_vel.angular.y = 0.0;
            cmd_vel.angular.z = 0.0;

            need_help_flag_ = true;
            collision_maneuver_flag_ = true;

            {
            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
            costmap_ros_global_->resetLayers();
            

            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
            costmap_ros_local_->resetLayers();
            }
            auto duration = std::chrono::milliseconds(500);  // 500 milliseconds
            rclcpp::sleep_for(duration);
            //如果尝试多次后仍然无法生成枝端路径，则尝试正常计算
            maneuver_counter_ ++;
            if(maneuver_counter_ > 5){
                maneuver_counter_ = 0;
                collision_maneuver_flag_ = false;
            }

        }
    }
    return cmd_vel;
}

/**********************************************************************************************
 *@brief:               自转以对准初始朝向
 *@introduction:        对准的是萝卜而不是路径的初始切向，所以此方法必须在updatePlanInLocal之后执行
 **********************************************************************************************/
bool V2PlannerROS::startANewSeg(geometry_msgs::msg::Twist& cmd_vel) {
    std::cout<<"(v2_planner_ros.cpp): start a new plan"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): start a new plan","purple");

    velocityController_.resetInPosistionFlag();

    // 非混合A*路段，自转对准
    if(seg_type_ != "forward_line" && seg_type_ != "forward_curve"&&
        seg_type_ != "back_line"    && seg_type_ != "back_curve"){
        std::cout<<"(v2_planner_ros.cpp): not hybrid seg, need to spin"<<std::endl;
        fileWrite_->writeEnd("(v2_planner_ros.cpp): not hybrid seg, need to spin");

        // 计算初始应该对准的朝向
        geometry_msgs::msg::PoseStamped start_pose = current_pose_local_;
        double yaw = atan2(pursuit_pose_.pose.position.y - current_pose_local_.pose.position.y ,
                           pursuit_pose_.pose.position.x - current_pose_local_.pose.position.x);

        tf2::Quaternion q;
        q.setRPY(0, 0, yaw);

        // Convert tf2::Quaternion to geometry_msgs::Pose
        geometry_msgs::msg::Pose start_pose;
        tf2::convert(q, start_pose.orientation);
    

    if(velocityController_.notAlign(current_pose_local_ , start_pose)) {
        // debug打印，可删除
        std::cout<<"(v2_planner_ros.cpp): not align to the start goal, spin to align to it"<<std::endl;
        fileWrite_->writeEnd("(v2_planner_ros.cpp): not align to the start goal, spin to align to it");

        std::cout<<"current_pose_local:"<<std::endl;
        fileWrite_->writeEnd("current_pose_local:");
        v2_local_planner::coutPose(current_pose_local_);
        fileWrite_->writePose(current_pose_local_);

        std::cout<<"start_pose:"<<std::endl;
        fileWrite_->writeEnd("start_pose:");
        v2_local_planner::coutPose(start_pose);
        fileWrite_->writePose(start_pose);

        // 若不用清理代价地图，则计算速度
        if(! clear_map_flag_ ) {
            isOK_ = velocityController_.spinToAheadToPose( 
                            cmd_vel,
                            limits_.getAccLimits(),
                            v2p_->getSimPeriod(),
                            odom_helper_,
                            current_pose_local_, 
                            current_pose_global_,
                            start_pose,
                            boost::bind(&V2Planner::checkTrajectory, v2p_, _1, _2, _3));
        } else {
            timer_++;
            if(timer_ > 20) {
                timer_ = 0;
                {
                boost::unique_lock<costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
                costmap_ros_global_->resetLayers();
        
                boost::unique_lock<costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
                costmap_ros_local_->resetLayers();
        
                //清理代价地图的标志位
                clear_map_flag_ = false;
                timer_1_ = 0;
                }
            }
            return true;
        }

        // 若isOK_说明计算的速度合法，反之不合法
        if(isOK_) {
            timer_ = 0;
            timer_1_ = 99;
            clear_map_flag_ = false;

            return true;
        } else {
            //初始自转对准朝向时如果会发生碰撞，则用混合A*规划一条避障路径
            std::cout<<"\033[45m(v2_planner_ros.cpp): "
                <<"\033[31mError when initial aligning\033[0m"<<std::endl;
            fileWrite_->writeError("(v2_planner_ros.cpp): Error when initial aligning");

            timer_ = 0;
            timer_1_ = 99;
            clear_map_flag_ = false;

            cmd_vel.linear.x = 0.0;
            cmd_vel.linear.y = 0.0;
            cmd_vel.angular.z = 0.0;
                
            //collision_maneuver_flag_ = true;
            pathManagerCore_.setUsedPlan();
            return true;
        }   
    } else {
        pathManagerCore_.setUsedPlan();
        return true;
    }
    // 混合A*路段，不自转，直接执行



    } else {
        std::cout<<"(v2_planner_ros.cpp): hybrid seg, no need to spin"<<std::endl;
        fileWrite_->writeEnd("(v2_planner_ros.cpp): hybrid seg, no need to spin");

        if(! clear_map_flag_ ){
            pathManagerCore_.setUsedPlan();
            return true;
        } else {
            timer_++;
            if(timer_ > 20){
                timer_ = 0;
                {
                boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
                costmap_ros_global_->resetLayers();
        
                boost::unique_lock<nav2_ostmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
                costmap_ros_local_->resetLayers();

                //清理代价地图的标志位
                clear_map_flag_ = false;
                timer_1_ = 0;
                }
            }
            return true;
        }
    }
}

// startANewSeg之后的执行过程
bool V2PlannerROS::executeASeg(geometry_msgs::msg::Twist& cmd_vel) {
    std::cout<<"\033[34m(v2_planner_ros.cpp): executeASeg()\033[0m"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): executeASeg()","purple");

    if(! clear_map_flag_ ) {
        isOK_ = velocityController_.spinAndGoCurveWithInvalidDistance(
                        cmd_vel,
                        limits_.getAccLimits(),
                        v2p_->getSimPeriod(),
                        odom_helper_,
                        current_pose_local_,
                        current_pose_global_,
                        pursuit_pose_,
                        seg_type_,
                        boost::bind(&V2Planner::checkTrajectory, v2p_, _1, _2, _3),
                        boost::bind(&V2Planner::checkTrajectoryWithInvalidDistance, v2p_,
                                    _1, _2, _3, _4,_5, _6),
                        distance_to_invalid_posi_,
                        invalid_part_,
                        emergency_trigger_,
                        false);
    } else {
        timer_++;
        if(timer_ > 5) {
            timer_ = 0;
            {
            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
            costmap_ros_global_->resetLayers();

            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
            costmap_ros_local_->resetLayers();

            clear_map_flag_ = false;
            timer_1_ = 0;
            }
        }
        return true;
    }
    std::cout << "distance to invalid position: " << std::to_string(distance_to_invalid_posi_)<<std::endl;
    fileWrite_->write("distance to invalid position");
    fileWrite_->writeEnd(std::to_string(distance_to_invalid_posi_));

    if(!isOK_ || distance_to_invalid_posi_ < 0.25 * inscribed_radius_) {
        std::cout << "\033[41mtoo close to obstacle\033[0m" << std::endl;
        fileWrite_->writeError("too close to obstacle");
        counter_too_near_ ++;
        if(counter_too_near_ > 5) {
            std::cout<<"\033[41mneed to maneuver\033[0m"<<std::endl;
            fileWrite_->writeError("need to maneuver");

            timer_ = 0;
            timer_1_ = 99;
            clear_map_flag_ = false;

            cmd_vel.linear.x = 0.0;
            cmd_vel.linear.y = 0.0;
            cmd_vel.angular.z = 0.0;
            collision_maneuver_flag_ = true;
        } else {
            std::cout << "\033[42mtry to clear map\033[0m" << std::endl;
            fileWrite_->writeWarn("try to clear map");

            timer_ = 0;
            timer_1_ = 99;
            clear_map_flag_ = true;

            cmd_vel.linear.x = 0.0;
            cmd_vel.linear.y = 0.0;
            cmd_vel.angular.z = 0.0;
        }
        return true;
    } else {
        timer_ = 0;
        timer_1_ = 99;
        counter_too_near_ = 0;
        clear_map_flag_ = false;

        return true;
    }
}

// 当前路段已完成，进入下一路段
bool V2PlannerROS::goToNextSeg(geometry_msgs::msg::Twist& cmd_vel) {
    std::cout<<"\033[46m(v2_planner_ros.cpp): \033[0mgo to next seg"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): go to next seg","purple");

    // 停车
    cmd_vel.linear.x = 0.0;
    cmd_vel.linear.y = 0.0;
    cmd_vel.linear.z = 0.0;
    cmd_vel.angular.x = 0.0;
    cmd_vel.angular.y = 0.0;
    cmd_vel.angular.z = 0.0;

    // 告知路径管理器，进入下一路段
    pathManagerCore_.nextSeg();
    pathManagerCore_.resetSoftPruneHistory();

    // 修改所有相关标志位
    near_to_goal_flag_ = false;
    poses_left_current_seg_ = 99;
    velocityController_.straight_flag_ = false;
    velocityController_.straight_flag_final_ = false;
    velocityController_.in_position_flag_ = false;

    velocityController_.linear_velocity_history_ = 0.0;
    velocityController_.linear_velocity_history_final_ = 0.0;
    return true;
}

bool V2PlannerROS::updatePlanInLocal(bool& jump_flag , bool& stop_fl) {
    std::cout << "(v2_planner_ros.cpp): updatePlanInLocal()" << std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): updatePlanInLocal()","purple");
    // 从planner_util（路径管理器）中取出前方的一段路径
    //同时能获取前方路段的合法与否
    bool obstacle_flag;
    bool slow_flag;
    if(! clear_map_flag_ ) {
        if(!remake_flag_) {
            if (!pathManagerCore_.getLocalPlanWithObstacleCheck(current_pose_global_, 
                                                         path_seg_global_map_,
                                                         distance_to_invaid_pose_get_local_plan_,
                                                         obstacle_flag,
                                                         poses_left_current_seg_)) {
                // 前方如果有障碍物，则慢行或停止或等待后绕障
                if(obstacle_flag) {
                    //如果距离尚远，则减速
                    if(distance_to_invaid_pose_get_local_plan_ > 2 * circum_radius_) {
                        std::cout << "\033[45m (v2_planner_ros.cpp):\033[0m" << "\033[33m obstacle ahead, slow down \033[0m"<<std::endl; 
                        fileWrite_->writeWarn("(v2_planner_ros.cpp): obstacle ahead, slow down");

                        slow_flag = true;
                        remake_flag_ = false;
                        jump_flag = false;
                        stop_fl = false;

                        clear_map_time_ = 0;
                    } else {
                        std::cout << "\033[45m (v2_planner_ros.cpp):\033[0m" << "\033[33m obstacle ahead, stop and remake \033[0m" << std::endl;
                        fileWrite_->writeError("(v2_planner_ros.cpp): obstacle ahead, stop and remake");

                        if(clear_map_time_ < 5) {
                            clear_map_flag_ = true;
                            jump_flag = true;

                            clear_map_time_ ++;
                            return false;
                        } else {
                            remake_flag_ = true;
                            // 此处可以选择remake_flag_ = false，以执行停障行为
                            if(! remake_flag_ ) {
                                clear_map_flag_ = true;
                                jump_flag = true;
                                stop_fl = true;
                                return false;
                            }
                            jump_flag = true;
                            stop_fl = true;
                            return false;
                        }
                    }
                } else {
                    //返回了false，也没有stop的标志，说明出了问题
                    std::cout<<"\033[45m (v2_planner_ros.cpp):\033[0m" <<"\033[31m cannot get the local plan \033[0m"<<std::endl; 
                    fileWrite_->writeError("(v2_planner_ros.cpp): cannot get the local plan");
                    
                    //既跳过此循环，又要停下来
                    jump_flag = true;
                    stop_fl = true;
                    return false;
                }
            } else { // 成功获取前方路段
                slow_flag = false;
                remake_flag_ = false;
                jump_flag = false;  
                stop_fl = false;
                timer_ = 0;
                timer_1_ = 99;
                clear_map_flag_ = false;
                clear_map_time_ = 0;
            }   
        } else { // 避障重规划
            //如果remake_flag_被置了真，说明需要重新制定计划，告知planner_util重新制定计划
            //在planner_util中，把重规划和getLocalPlan分离开来
            std::cout<<"\033[45m (v2_planner_ros.cpp):\033[0m"
               <<"\033[31m going to remake the plan \033[0m"<<std::endl; 
            fileWrite_->writeWarn("(v2_planner_ros.cpp): going to remake the plan");
            if(pathManagerCore_.remakePlan(current_pose_global_)) {
                std::cout<<"\033[45m (v2_planner_ros.cpp):\033[0m" << "\033[32m successfully remake the plan \033[0m"<<std::endl; 
                fileWrite_->writeEnd("(v2_planner_ros.cpp): successfully remake the plan","green");
                //避障重规划成功，跳过此循环，下个循环不再
                remake_flag_ = false;
                jump_flag = true;

                // 既然成功制定了计划，则恢复所有与代价地图清理的记号
                timer_ = 0;
                timer_1_ = 99;
                clear_map_flag_ = false;
                return false;
            } else {
                remake_flag_ = true;
                jump_flag = true;

                //没有成功制定计划，则跳过此轮控制循环，下一循环清理代价地图
                //need_help_flag = true;
                clear_map_flag_ = true;

                return false;
            }
        }
        if(path_seg_global_map_.empty()) {
            std::cout<<"\033[45m (v2_planner_ros.cpp): \033[0m"
                    <<"\033[31mtransformed plan is empty \033[0m"<<std::endl; 
            fileWrite_->writeError("(v2_planner_ros.cpp): transformed plan is empty");
        
            jump_flag = true;
            stop_fl = true;
            return false;
        }
    } else {
        timer_++;
        if(timer_ > 5){
            timer_ = 0;
            {
            boost::unique_lock<costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
            costmap_ros_global_->resetLayers();
            

            boost::unique_lock<costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
            costmap_ros_local_->resetLayers();
        
            //清理代价地图的标志位
            clear_map_flag_ = false;
            timer_1_ = 0;
            }
        }
        jump_flag = true;
        return false;
    }
    // 至此则成功获得前方路段
    std::cout<<"successfully get local seg, original seg remain poses no.:"<<std::to_string(poses_left_current_seg_)<<std::endl;
    fileWrite_->write("successfully get local seg, seg remain poses no.:");
    fileWrite_->writeEnd(std::to_string(poses_left_current_seg_));

    jump_flag = false;
    stop_fl = false;

    timer_ = 0;
    timer_1_ = 99;
    clear_map_flag_ = false;

    // 更新局部处理器里的路段
    bool update_ok = v2p_->updatePlanAndLocalCosts(current_pose_global_,
                                                 current_pose_local_,
                                                 path_seg_global_map_,
                                                 costmap_ros_local_->getRobotFootprint());
    if(!update_ok) {
        std::cout<<"\033[31m fail to update plan \033[0m"<<std::endl;
        fileWrite_->writeError("fail to update plan");

        jump_flag = true;
        stop_fl = true;
        return false;
    }
    // 计算跟踪点
    bool get_pursuit_pose_ok = v2p_->pursuitPose(circum_radius_,
                                               inscribed_radius_,
                                               seg_type_,
                                               pursuit_pose_,
                                               pursuit_pose_global_,
                                               emergency_trigger_);
    if(!get_pursuit_pose_ok){
        std::cout<<"\033[31m fail to get pursuit pose \033[0m"<<std::endl;
        fileWrite_->writeError("fail to get pursuit pose");

        jump_flag = true;
        stop_fl = true;
        return false;
    }
    // 修改紧急处理位（全局、局部联合作用）
    if(slow_flag) emergency_trigger_ = true;
    // fabu
    pursuit_pose_pub_->publish(pursuit_pose_global_);
    pursuit_point_.header = pursuit_pose_global_.header;
    pursuit_point_.point.x = pursuit_pose_global_.pose.position.x;
    pursuit_point_.point.y = pursuit_pose_global_.pose.position.y;
    pursuit_point_.point.z = pursuit_pose_global_.pose.position.z;
    pursuit_point_pub_->publish(pursuit_point_);
    return true;
}

bool V2PlannerROS::nearProcess(geometry_msgs::msg::Twist& cmd_vel) {
    std::cout<<"(v2_planner_ros.cpp): nearProcess()"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): nearProcess()","purple");

    //=========================================================
    //                                          用标志位锁定状态
    //=========================================================   
    near_to_goal_flag_ = true;

    //=========================================================
    //                     如果x,y已就位，则只自转，不管x,y的漂移
    //=========================================================
    if( velocityController_.assertInPositionFlag() ){
        //--------------------------------------------
        //                           debug打印，可删除
        //--------------------------------------------   
        std::cout<<"(v2_planner_ros.cpp): final position reached"<<std::endl;
        fileWrite_->writeEnd("(v2_planner_ros.cpp): final position reached");

        std::cout<<"(v2_planner_ros.cpp): current pose in odom:"<<std::endl;
        v2_local_planner::coutPose(current_pose_local_);
        fileWrite_->writeEnd("(v2_planner_ros.cpp): current pose in odom:");
        fileWrite_->writePose(current_pose_local_);

        std::cout<<"(v2_planner_ros.cpp): goal pose in odom:"<<std::endl;
        v2_local_planner::coutPose(global_end_local_);
        fileWrite_->writeEnd("(v2_planner_ros.cpp): goal pose in odom:");
        fileWrite_->writePose(global_end_local_);

        //--------------------------------------------
        //                          判断是否可强制就位
        //-------------------------------------------- 
        geometry_msgs::PoseStamped goal_pose_in_base;
        v2_local_planner::poseOdomToBase(current_pose_local_ , global_end_local_ , goal_pose_in_base);

        v2_local_planner::coutPose(goal_pose_in_base);
        fileWrite_->writePose(goal_pose_in_base);

        velocityController_.forceSuccess(cmd_vel, 
                                        current_pose_local_, 
                                        global_end_local_);


    if(! clear_map_flag_ ){
        isOK_ = velocityController_.computeVelocityCommandsStopRotate(
                        cmd_vel,
                        limits_.getAccLimits(),
                        v2p_->getSimPeriod(),
                        odom_helper_,
                        current_pose_local_,
                        current_pose_global_,
                        boost::bind(&V2Planner::checkTrajectory, v2p_, _1, _2, _3));
    } else {
        timer_++;
        if(timer_ > 20) {
            timer_ = 0;
            {
            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
            costmap_ros_global_->resetLayers();

            boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
            costmap_ros_local_->resetLayers();
    
            //清理代价地图的标志位
            clear_map_flag_ = false;
            timer_1_ = 0;
            }
        }
        return true;
    }

            
    if(isOK_) {
        timer_ = 0;
        timer_1_ = 99;
        clear_map_flag_ = false;
        return true;
    } else {
        std::cout<<"\033[31m(v2_planner_ros.cpp): collision during near processing final spin\033[0m"
                <<std::endl;
        fileWrite_->writeError("(v2_planner_ros.cpp): collision during near processing final spin");


        clear_map_flag_ = true;
        cmd_vel.linear.x = 0.0;
        cmd_vel.linear.y = 0.0;
        cmd_vel.angular.z = 0.0;
        return true;
    }
  }


  //=========================================================
  //                           如果x,y没就位，则自转对准再前进
  //=========================================================
  if(!clear_map_flag_){
    isOK_ = velocityController_.spinAndGoFinal(
                        cmd_vel,
                        limits_.getAccLimits(),
                        v2p_->getSimPeriod(),
                        odom_helper_,
                        current_pose_local_,
                        current_pose_global_,
                        global_end_local_,
                        boost::bind(&V2Planner::checkTrajectory, v2p_, _1, _2, _3),
                        boost::bind(&V2Planner::checkTrajectoryWithInvalidDistance, v2p_,
                                        _1, _2, _3, _4, _5, _6));
  } else {
    timer_++;
    if(timer_ > 20){
      timer_ = 0;
      {
      boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_global(*(costmap_global_->getMutex()));
      costmap_ros_global_->resetLayers();

      boost::unique_lock<nav2_costmap_2d::Costmap2D::mutex_t> lock_local(*(costmap_local_->getMutex()));
      costmap_ros_local_->resetLayers();
  
      //清理代价地图的标志位
      clear_map_flag_ = false;
      timer_1_ = 0;
      }
    }
    return true;
  }

  if(isOK_){
    timer_ = 0;
    timer_1_ = 99;
    clear_map_flag_ = false;
    return true;
  } else {
    std::cout<<"\033[31m(v2_planner_ros.cpp): collision during near processing spin and go\033[0m"
             <<std::endl;
    fileWrite_->writeError("(v2_planner_ros.cpp): collision during near processing spin and go");
    clear_map_flag_ = true;

    cmd_vel.linear.x = 0.0;
    cmd_vel.linear.y = 0.0;
    cmd_vel.angular.z = 0.0;
    return true;
  }
}
// 获取当前任务的终点，用于判断是否需要进入nearProcess程序
void V2PlannerROS::checkGlobalPlanEnd() {
    std::cout<<"\033[43m(v2_planner_ros.cpp): checkGlobalPlanEnd()\033[0m"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): checkGlobalPlanEnd()","purple");

    pathManagerCore_.getGoalInLocalFrame(global_end_local_);

    // debug打印，可删除
    std::cout<<"(v2_planner_ros.cpp): the end of total plan in odom frame:"<<std::endl;
    v2_local_planner::coutPose(global_end_local_);
    fileWrite_->writeEnd("(v2_planner_ros.cpp): the end of total plan in odom frame:");
    fileWrite_->writePose(global_end_local_);

    geometry_msgs::msg::PoseStamped seg_end_base;
    v2_local_planner::poseOdomToBase(current_pose_local_ , global_end_local_ , seg_end_base);

    std::cout<<"(v2_planner_ros.cpp): the end of total plan in base frame:"<<std::endl;
    v2_local_planner::coutPose(seg_end_base);
    fileWrite_->writeEnd("(v2_planner_ros.cpp): the end of total plan in base frame:");
    fileWrite_->writePose(seg_end_base);
}

// 获取当前执行路段的终点，用于判断是否需要切换到下一路段
void V2PlannerROS::checkSegmentPlanEnd() {
    std::cout<<"\033[43m(v2_planner_ros.cpp): checkSegmentPlanEnd()\033[0m"<<std::endl;
    fileWrite_->writeEnd("(v2_planner_ros.cpp): checkSegmentPlanEnd()","purple");

    pathManagerCore_.getSegmentEndInLocalFrame(seg_end_local_);
    // debug打印，可删除
    std::cout<<"the end of current segment in odom frame:"<<std::endl;
    v2_local_planner::coutPose(seg_end_local_);
    fileWrite_->writeEnd("the end of current segment in odom frame:");
    fileWrite_->writePose(seg_end_local_);
    geometry_msgs::msg::PoseStamped seg_end_base;
    v2_local_planner::poseOdomToBase(current_pose_local_,seg_end_local_,seg_end_base);

    std::cout<<"the end of current segment in base frame:"<<std::endl;
    v2_local_planner::coutPose(seg_end_base);
    fileWrite_->writeEnd("the end of current segment in base frame:"); 
    fileWrite_->writePose(seg_end_base);
}

/*************************************************************************************************
 * @brief: 速度预测到碰撞后的操作
 * @description: 
 *     2024.01.03: 暂时不用，避障速度的修正均放在了velocity_controller中
 *                 但后期需要优化避障策略：当距离障碍物太近时，需要规划一小段反向的操作，这是就需要在这里进行协调了
 *     2024.01.08: 在velocity_controller中有基于采样的避障速度算法，但此算法只适合中远距离的避障，
                   且只作用于接下来的一个控制周期，当碰撞距离过近时，就需要规划一小段路径来串联接下来的
                   一长段控制周期，这个方法会调取planner_util中的方法，规划一小段的枝端路径来执行
 *************************************************************************************************/
bool V2PlannerROS::velocityForseeCollisionManeuver(){
  std::cout<<"\033[35m(v2_planner_ros.cpp): velocityForseeCollisionManeuver()\033[0m"<<std::endl;
  fileWrite_->writeEnd("(v2_planner_ros.cpp): velocityForseeCollisionManeuver()","purple");
    
  bool branch_ok = pathManagerCore_.branchPathPlan(current_pose_global_ , circum_radius_);

  return branch_ok;
}
/*************************************************************************************************
 *@brief:          判断当前路段是否执行完毕
 *@intorduction:   判断方法：当前路段规定必须前进还是后退
                   ——若是前进，有没有满足以下条件：
                     1. 软裁剪索引有没有到末端
                     2. 当前车身与路段终点之间的距离有没有小于一定值
                         如果是A*路径，则车身坐标和路段终点坐标都相对/map坐标系，
                         并非，A*路径在checkSegmentPlanEnd()是返回的也是终点坐标在/odom坐标系里的坐标
                         如果是混合A*路径，则车身坐标和路段终点坐标都相对/odom坐标系
                         倒退同理
                     3. 路段终点的坐标在车身坐标系中的坐标的x值是否为负值
                   ——若是后退
                     1,2 同理
                     3. 路段终点的坐标在车身坐标系中的坐标的x值是否为正值    
 *************************************************************************************************/
bool V2PlannerROS::isCurrentSegFinished(){

    //================================================
    //                 相对坐标判断是否已经经过路段终点
    //================================================
    //把前面正文里的checkSegmentPlanEnd()给挪到这里
    checkSegmentPlanEnd();
    
    //车身坐标：current_pose_local_
    //终点坐标：seg_end_local_
    geometry_msgs::msg::PoseStamped pose_relative;
    v2_local_planner::poseOdomToBase(current_pose_local_, seg_end_local_, pose_relative);


    bool is_passed = false;
    if(seg_type_ == "forward_line" || seg_type_ == "forward_curve" || 
        seg_type_ == "manual" || seg_type_ == "line" || seg_type_ == "curve"){
        if(pose_relative.pose.position.x <= 0.0){
        is_passed = true;
        }else{
        is_passed = false;
        }
    }else{
        if(pose_relative.pose.position.x >= 0.0){
        is_passed = true;
        }else{
        is_passed = false;
        }
    }

    //================================================
    //              seg剩余pose个数判断是否到达终点附近
    //================================================
    //planner_util在更新局部路段时会返回本seg剩余的pose数量
    bool index_to_end = false;
    if(poses_left_current_seg_ > 4) index_to_end = false;
    else index_to_end = true;

    //================================================
    //   当前位置与seg end的直线距离判断是否到达终点附近
    //================================================
    bool is_near_to_end = false;

    double distance = sqrt(((seg_end_local_.pose.position.x - current_pose_local_.pose.position.x)*
                            (seg_end_local_.pose.position.x - current_pose_local_.pose.position.x))+
                            ((seg_end_local_.pose.position.y - current_pose_local_.pose.position.y)*
                            (seg_end_local_.pose.position.y - current_pose_local_.pose.position.y)));

    if(distance < 0.085) is_near_to_end = true;

    

    //================================================
    //                                        综合判断
    //================================================
    //TODO: 混合A*路段最好别带上is_near_to_end判断
    if( (is_passed && (index_to_end || is_near_to_end)) || 
        is_near_to_end){
        return true;
    }

    return false;    
}

void V2PlannerROS::publishZeroVelocity(){
    geometry_msgs::Twist cmd_vel;
    cmd_vel.linear.x = 0.0;
    cmd_vel.linear.y = 0.0;
    cmd_vel.linear.z = 0.0;
    
    cmd_vel.angular.x = 0.0;
    cmd_vel.angular.y = 0.0;
    cmd_vel.angular.z = 0.0;

    for(int i = 0; i < 5; i++){
        vel_pub_.publish(cmd_vel);
        auto duration = std::chrono::milliseconds(200);  // 500 milliseconds
        rclcpp::sleep_for(duration);
    }
}


}

// Register this controller as a nav2_core plugin
PLUGINLIB_EXPORT_CLASS(v2_local_planner::V2PlannerROS, nav2_core::Controller)