#include <geometry_msgs/msg/pose_stamped.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <geometry_msgs/msg/point.hpp>
#include <geometry_msgs/msg/twist.hpp>
#include <geometry_msgs/msg/pose_array.hpp>

#include <vector>
#include <list>
#include <queue>

typedef geometry_msgs::msg::Point Point;
typedef std::vector<Point> PointVec;

typedef geometry_msgs::msg::PointStamped PointStamped;
typedef std::vector<PointStamped> PointStampedVec;

typedef geometry_msgs::msg::PoseStamped PoseStamped;
typedef std::vector<PoseStamped> PoseStampedVec;
typedef std::vector<PoseStampedVec> PoseStampedVecVec;

typedef std::vector<double> DoubleVec;

typedef std::string String;
typedef std::vector<String> StringVec;

typedef geometry_msgs::msg::PoseArray PoseArray;
