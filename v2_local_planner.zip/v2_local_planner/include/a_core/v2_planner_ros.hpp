#pragma once

#include <boost/shared_ptr.hpp>
#include <boost/thread.hpp>

#include <tf2_ros/buffer.h>

// #include <dynamic_reconfigure/server.h>

#include <angles/angles.h>

#include <nav_msgs/msg/odometry.hpp>

#include <nav2_costmap_2d/costmap_2d_ros.hpp>
#include <nav2_core/controller.hpp>

#include <geometry_msgs/msg/pose_with_covariance_stamped.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <std_msgs/msg/bool.hpp>

#include "b_path_manager/path_manager_core.hpp"

#include "b_local_process/v2_planner.hpp"

#include "b_velocity_controller/velocity_controller.hpp"

#include "c_tools/type_define.hpp"
#include "c_tools/file_write.hpp"
#include "c_tools/goal_functions.hpp"
#include "c_tools/odometry_helper_ros.hpp"
#include "c_tools/local_planner_limits.hpp"

namesapce v2_local_planner {

class V2PlannerROS : public nav2_core::Controller, public rclcpp::Node {
public:
    V2PlannerROS();
    ~V2PlannerROS() {};

    void configure(
        const rclcpp_lifecycle::LifecycleNode::WeakPtr & parent,
        std::string name, const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::shared_ptr<nav2_costmap_2d::Costmap2DROS> costmap_ros);

    void cleanup();
    void activate();
    void deactivate();
    void setSpeedLimit(const double & speed_limit, const bool & percentage);

    geometry_msgs::msg::TwistStamped computeVelocityCommands(
        const geometry_msgs::msg::PoseStamped & pose,
        const geometry_msgs::msg::Twist & velocity,
        nav2_core::GoalChecker * goal_checker);
    
    void setPlan(const nav_msgs::msg::Path & path);

    bool isGoalReached();

    bool isInitialized() { return initialized_; }

private:
    nav_msgs::msg::Path transformGlobalPlan(const geometry_msgs::msg::PoseStamped & pose);

    bool transformPose(
        const std::shared_ptr<tf2_ros::Buffer> tf,
        const std::string frame,
        const geometry_msgs::msg::PoseStamped & in_pose,
        geometry_msgs::msg::PoseStamped & out_pose,
        const rclcpp::Duration & transform_tolerance
    ) const;

    nav_msgs::msg::Path global_plan_;
    std::shared_ptr<rclcpp_lifecycle::LifecyclePublisher<nav_msgs::msg::Path>> global_pub_;

    //#################################################
    //                     关键参数和类
    //#################################################
    std::shared_ptr<tf2_ros::Buffer> tf_;
    std::string plugin_name_;
    rclcpp::Clock::SharedPtr clock_;
    //==============================
    //             三大剑
    //==============================
    v2_local_planner::PathManagerCore    pathManagerCore_;//< 全局层
    boost::shared_ptr<V2Planner>         v2p_;//< 局部层
    v2_local_planner::VelocityController velocityController_;//< 速度层

    //==============================
    //           代价地图
    //==============================
    nav2_costmap_2d::Costmap2D*    costmap_local_;
    nav2_costmap_2d::Costmap2DROS* costmap_ros_local_;
    nav2_costmap_2d::Costmap2D*    costmap_global_;  
    nav2_costmap_2d::Costmap2DROS* costmap_ros_global_;

    // 动态重配置

    //#################################################
    //                    日志记录类
    //#################################################
    v2_local_planner::fileWrite* fileWrite_;

    //#################################################
    //                  里程计数据交互器
    //#################################################
    v2_local_planner::OdometryHelperRos odom_helper_;
    String odom_topic_;

    bool setup_;
    bool initialized_;

    //#################################################
    //                   混合A*避障申请
    //#################################################
    bool velocityForseeCollisionManeuver();
    bool collision_maneuver_flag_;
    int  maneuver_counter_;

    //#################################################
    //                   人工干预的处理
    //#################################################
    //用于发送需要人工干预的消息

    //#################################################
    //                    离驳处理部分
    //#################################################


    //#################################################
    //                  对每一路段路段的执行
    //#################################################
    //=====================================
    //                获得当前位姿
    //=====================================
    PoseStamped current_pose_local_;
    PoseStamped current_pose_global_;

    //=====================================
    //       从全局层中获得局部路段及相关信息
    //=====================================
    bool updatePlanInLocal(bool& jump_flag,bool& stop_flag);
    PoseStampedVec path_seg_global_map_;
    PoseStampedVec path_seg_local_map_;

    // 在get local plan时获取的距离非法点的距离
    double distance_to_invaid_pose_get_local_plan_;
    int    poses_left_current_seg_;
    bool   emergency_trigger_;
    String seg_type_;

    // 当全局层返回需要重新制定规划的信号后，停下小车，并将此标志位置真
    // 提醒下一个周期进行全局重规划
    bool remake_flag_;

    // 保存全局任务的终点、本段任务的终点
    void checkGlobalPlanEnd();
    void checkSegmentPlanEnd();
    PoseStamped global_end_local_;
    PoseStamped seg_end_local_;

    bool goToNextSeg(geometry_msgs::msg::Twist& cmd_vel);

    //=====================================
    //           局部路段————>局部层
    //=====================================
    PoseStamped    pursuit_pose_global_;
    PoseStamped    pursuit_pose_;
    PointStamped   pursuit_point_;
    rclcpp::Publisher<PoseStamped>::SharedPtr pursuit_pose_pub_;
    rclcpp::Publisher<PoseStamped>::SharedPtr pursuit_point_pub_;
    
    //=====================================
    //                起始对准
    //=====================================
    bool startANewSeg(geometry_msgs::msg::Twist& cmd_vel);

    //=====================================
    //                中间执行
    //=====================================    
    bool executeASeg(geometry_msgs::msg::Twist& cmd_vel);

    //TODO: 当前路段是否执行完毕
    bool isCurrentSegFinished();

    int    counter_too_near_;//<检测到碰撞太近时，先清几轮地图
    double distance_to_invalid_posi_ ;//<用速度预测获取的碰撞预测距离
    String invalid_part_;//<碰撞发生的阶段：前进？自转？
    bool   isOK_;

    //=====================================
    //          最后一段的特殊执行策略
    //=====================================
    bool is_the_final_;
    bool nearProcess(geometry_msgs::msg::Twist& cmd_vel);
    bool near_to_goal_flag_;

    //用于判断是否到达终点
    double inscribed_radius_; 
    double circum_radius_;

    //==============================
    //           地图清理使用
    //==============================
    bool clear_map_flag_;
    int  clear_map_time_;
    int  timer_;
    int  timer_1_;

    v2_local_planner::LocalPlannerLimits limits_;
    bool is_global_plan_collision_;

    //#################################################
    //                                   简单的速度发布
    //#################################################
    //绝不可与上层的速度发布相冲突
    //TODO: 会让控制周期超期，暂时不用
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr vel_pub_;
    void publishZeroVelocity();  
};


} // namespace v2_local_planner