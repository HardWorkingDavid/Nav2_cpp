#pragma once

#include <vector>
#include <Eigen/Core>

#include <nav2_costmap_2d/costmap_2d.hpp>
#include <tf2_ros/buffer.h>
#include <nav_msgs/msg/path.hpp>

#include <visualization_msgs/msg/marker_array.hpp>
#include <geometry_msgs/msg/point_stamped.hpp>
#include <geometry_msgs/msg/pose_array.hpp>

#include "b_path_manager/path_manager_core.hpp"

#include "c_traj_relative/traj_generate/simple_trajectory_generator.hpp"
#include "c_traj_relative/traj_generate/trajectory.hpp"
#include "c_traj_relative/traj_cost/obstacle_cost_function.hpp"

#include "c_tools/goal_functions.hpp"
#include "c_tools/type_define.hpp"
#include "c_tools/local_planner_limits.hpp"
#include "c_tools/file_write.hpp"


namespace v2_local_planner{
class V2Planner{
public:
V2Planner(
  String                                 name, 
  PathManagerCore*                       pathManagerCore,
  fileWrite*                             fileWrite,
  tf2_ros::Buffer*                       tf,
  costmap_2d::Costmap2D*                 costmap_local,
  String                                 global_frame_local,
  costmap_2d::Costmap2D*                 costmap_global,
  String                                 global_frame_global );


bool 
checkTrajectory(
  Eigen::Vector3f                        pos,
  Eigen::Vector3f                        vel,
  Eigen::Vector3f                        vel_samples);

bool 
checkTrajectoryWithInvalidDistance(
  Eigen::Vector3f                        pos,
  Eigen::Vector3f                        vel,
  Eigen::Vector3f                        vel_samples,
  bool                                   show_or_not,
  double&                                invalid_distance,
  std::vector<bool>&                     colli_parts);

bool
updatePlanAndLocalCosts(
  const PoseStamped&                     current_pose_global,
  const PoseStamped&                     current_pose_local,
  const PoseStampedVec&                  path_seg_map,
  const PointVec&                        footprint_spec);
      
bool
pursuitPose(
  const double&                          circumscribed_radius,
  const double&                          inscribed_radius,
  const String&                          seg_type,
  PoseStamped&                           pursuit_pose,
  PoseStamped&                           pursuit_pose_viz_global,
  bool&                                  emergency_trigger);

double getSimPeriod() { return sim_period_; }

void 
poseCheckCircle(
  const PoseStamped&                     check_pose,
  const double&                          circumscribed_radius,
  double&                                invalid_radius,
  std::vector<double>&                   invalid_position_x,
  std::vector<double>&                   invalid_position_y);

private:
PathManagerCore*                           pathManagerCore_;
fileWrite*                                 fileWrite_;
tf2_ros::Buffer*                           tf_;

nav2_costmap_2d::Costmap2D*                costmap_local_;
String                                     costmap_frame_local_;
  
nav2_costmap_2d::Costmap2D*                costmap_global_;
String                                     costmap_frame_global_;

//存放着被变换到local_cost_map下的global_plan段
PoseStamped                                current_pose_global_;
PoseStamped                                current_pose_local_;

PoseStampedVec                             global_plan_seg_pruned_;
PoseStampedVec                             local_plan_seg_pruned_;

boost::mutex                               configuration_mutex_;
      
double                                     occdist_scale_;
double                                     sim_period_;
v2_local_planner::Trajectory               result_traj_;

Eigen::Vector3f                            vsamples_;

v2_local_planner::SimpleTrajectoryGenerator    generator_;
v2_local_planner::ObstacleCostFunction         obstacle_costs_;

bool 
isCurve(
  std::vector<geometry_msgs::msg::PoseStamped>& path_seg);

};
}

